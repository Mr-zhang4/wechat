## 设置代理GO PROXY 
### go version >= 1.13
```
go env -w GOPROXY=https://goproxy.cn,direct
```

## 依赖框架
### YoyoGo [英文介绍](https://github.com/yoyofx/yoyogo/blob/master/README_En.md "中文介绍")
YoyoGo 一个简单、轻量、快速、基于依赖注入的微服务框架

* 文档： https://github.com/yoyofx/yoyogo/wiki
* 作者:   张磊-易车