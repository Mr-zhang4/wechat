package httpclient

type UploadFile struct {
	// 表单名称
	Name string
	// 文件路径
	Filepath string
}
