package abstractions

type IConfigurationProperties interface {
	GetSection() string
}
