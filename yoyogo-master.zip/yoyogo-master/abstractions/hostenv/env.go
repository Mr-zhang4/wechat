package hostenv

const (
	Dev  = "dev"
	Prod = "prod"
	Test = "test"
)
