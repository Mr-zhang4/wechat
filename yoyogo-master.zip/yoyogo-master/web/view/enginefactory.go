package view

func CreateViewEngine() IViewEngine {
	return NewDefaultViewEngine()
}
