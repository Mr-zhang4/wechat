package mvc

type StatusCoder interface {
	StatusCode() int
}
