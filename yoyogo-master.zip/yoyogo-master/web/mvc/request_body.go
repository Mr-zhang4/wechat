package mvc

type RequestBody struct {
}

type RequestGET struct {
}

type RequestPOST struct {
}
