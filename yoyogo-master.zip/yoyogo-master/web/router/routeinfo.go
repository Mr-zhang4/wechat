package router

type Info struct {
	Method string
	Path   string
	Type   string
}
