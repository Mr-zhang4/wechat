package console

const ProjectItem_conf_yml = `
yoyogo:
  application:
    name: {{.ModelName}}
    metadata: "dev"
    server:
      type: "console"
`
