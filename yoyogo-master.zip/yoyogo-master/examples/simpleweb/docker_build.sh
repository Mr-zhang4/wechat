# exec root dir by yoyogo

docker build -t ccr.ccs.tencentyun.com/tsf_86509022/yoyogo_demo:dev-45 -f ./examples/simpleweb/Dockerfile .


docker push ccr.ccs.tencentyun.com/tsf_86509022/yoyogo_demo:dev-45