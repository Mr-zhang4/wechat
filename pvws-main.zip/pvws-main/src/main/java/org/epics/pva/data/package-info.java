/** PV Access Data API
 *
 *  <p>All PV Access data is based on {@link org.epics.pva.data.PVAData},
 *  but most practical API starts with {@link org.epics.pva.data.PVAStructure}.
 */
package org.epics.pva.data;
