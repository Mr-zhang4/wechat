/** Common code internal to the server and client
 */
package org.epics.pva.common;
