/** PV Access Data API for normative types
 *
 *  <p>Helpers for dealing with commonly used {@link org.epics.pva.data.PVAStructure}s
 */
package org.epics.pva.data.nt;
