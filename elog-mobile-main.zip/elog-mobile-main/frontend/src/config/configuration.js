module.exports = {
    // Development
    serverPath: "http://localhost:3001",
    // serverPath: "http://10.1.44.253:3001",

    // Production
    // serverPath: "http://10.1.236.126:3001",
}