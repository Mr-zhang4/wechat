<template>
	<div style="width: 90%; margin: auto;">
        <h4 style="text-align: left; color: RGB(33, 150, 243); margin-bottom: 0px;">1. 软件说明</h4>
        <p style="text-indent: 2em">
            Elog电子日志系统手机版。
        </p>
    </div>
</template>

<script>
export default {
	
}
</script>

<style scoped>

</style>
