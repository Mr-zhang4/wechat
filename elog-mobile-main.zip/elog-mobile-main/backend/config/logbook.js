
module.exports = {
    // url: "http://elog.csns.ihep.ac.cn/",
    url: "https://elog.psi.ch/elogs/"
}