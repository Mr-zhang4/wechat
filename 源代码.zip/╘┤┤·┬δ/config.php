<?php exit();?>
{		
    "CorpId"     : "",
    "TxlSecret"  : "",
    "AppsConfig" : [
        { 
            "AppDesc": "",               
            "AgentId": 1000001,
            "Secret" : "",
            "Token"  : "",
            "EncodingAESKey":""            
        },
        { 
            "AppDesc": "",               
            "AgentId": 1000002,
            "Secret" : "",
            "Token"  : "",
            "EncodingAESKey":""            
        }
    ],
    "AlarmAgentId"  : "1000002",
    "AlarmAminUserid"  : "ZhangYuLiang|XueKangJia",
    "MysqlDBname"  : "almwechat",
    "MysqlDBUser"  : "",
    "MysqlDBPassword"  : ""
    
}
