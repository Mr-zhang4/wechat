<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,user-scalable=yes"/>
    <title>报警推送订阅</title>
    <link rel="stylesheet" type="text/css" href="style/weui.css">
</head>
<body>
<div align="center">
	<img width="90%" height="80" src="logo.png"/>
</div>
<br>
<br>
    <div style="text-align:center">
      <div class="weui-msg__icon-area"><i class="weui-icon-warn weui-icon_msg"></i></div>
      <div class="weui-msg__text-area">
        <h2 class="weui-msg__title">错误</h2>
        <p class="weui-msg__desc">非授权用户，禁止访问</p>
      </div>
    </div>

	
	<br>
	<div class="weui-footer">
  	<p class="weui-footer__text">Copyright &copy; CSNS Accelerator Control Group</p>
  </div>
<script>
</script>
</body>
</html>
