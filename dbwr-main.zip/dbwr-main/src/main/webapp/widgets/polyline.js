
function set_poly_line_color(widget, color)
{
    widget.find("polyline").attr("stroke", color);
}
